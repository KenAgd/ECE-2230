#!/usr/bin/sh
#
# MP1 place in student directory
./lab2 < ../tests/t00testinput > gradingout_t00testinput
./lab2 < ../tests/t01nolist > gradingout_t01nolist
./lab2 < ../tests/t02destruct > gradingout_t02destruct
./lab2 < ../tests/t03oneadd > gradingout_t03oneadd
./lab2 < ../tests/t04oneaddtrim > gradingout_t04oneaddtrim
./lab2 < ../tests/t05oneaddclear > gradingout_t05oneaddclear
./lab2 < ../tests/t06oneaddmatch > gradingout_t06oneaddmatch
./lab2 < ../tests/t07sort > gradingout_t07sort
./lab2 < ../tests/t08sortreplace > gradingout_t08sortreplace
./lab2 < ../tests/t09notfullreplace > gradingout_t09notfullreplace
./lab2 < ../tests/t10trim > gradingout_t10trim
./lab2 < ../tests/t11clearold > gradingout_t11clearold
./lab2 < ../tests/t12match > gradingout_t12match
./lab2 < ../tests/t13dblcreate > gradingout_t13dblcreate
./lab2 < ../tests/t14emptylist > gradingout_t14emptylist
./lab2 < ../tests/t15emptytrim > gradingout_t15emptytrim

